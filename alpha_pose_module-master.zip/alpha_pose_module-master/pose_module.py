import os
import torch
import cv2
import numpy as np
import time
import copy
from SPPE.src.main_fast_inference import *
from torchsample.transforms import SpecialCrop, Pad
import math
import torch.utils.data as data
import argparse
import torch
parser = argparse.ArgumentParser(description='PyTorch AlphaPose')
parser.add_argument('--inputResH', default=320, type=int,
                    help='Input image height')
parser.add_argument('--inputResW', default=256, type=int,
                    help='Input image width')
parser.add_argument('--outputResH', default=80, type=int,
                    help='Output heatmap height')
parser.add_argument('--outputResW', default=64, type=int,
                    help='Output heatmap width')
opt = parser.parse_args()

class Mscoco(data.Dataset):
    def __init__(self, train=True, sigma=1,
                 scale_factor=(0.2, 0.3), rot_factor=40, label_type='Gaussian'):
        self.img_folder = '../data/coco/images'    # root image folders
        self.is_train = train           # training set or test set
        self.inputResH = opt.inputResH
        self.inputResW = opt.inputResW
        self.outputResH = opt.outputResH
        self.outputResW = opt.outputResW
        self.sigma = sigma
        self.scale_factor = scale_factor
        self.rot_factor = rot_factor
        self.label_type = label_type

        self.nJoints_coco = 17
        self.nJoints_mpii = 16
        self.nJoints = 33

        self.accIdxs = (1, 2, 3, 4, 5, 6, 7, 8,
                        9, 10, 11, 12, 13, 14, 15, 16, 17)
        self.flipRef = ((2, 3), (4, 5), (6, 7),
                        (8, 9), (10, 11), (12, 13),
                        (14, 15), (16, 17))

    def __getitem__(self, index):
        pass

    def __len__(self):
        pass


def im_to_torch(img):
	img = np.transpose(img, (2, 0, 1))  # C*H*W
	img = to_torch(img).float()
	if img.max() > 1:
		img /= 255
	return img

def to_torch(ndarray):
	if type(ndarray).__module__ == 'numpy':
		return torch.from_numpy(ndarray)
	elif not torch.is_tensor(ndarray):
		raise ValueError("Cannot convert {} to torch tensor"
						 .format(type(ndarray)))
	return ndarray


def cropBox(img, ul, br, resH, resW):
	ul = ul.int()
	br = br.int()
	lenH = max(br[1] - ul[1], (br[0] - ul[0]) * resH / resW)
	lenW = lenH * resW / resH
	if img.dim() == 2:
		img = img[np.newaxis, :]

	newDim = torch.IntTensor((img.size(0), int(lenH), int(lenW)))
	newImg = img[:, ul[1]:, ul[0]:]
	# Crop and Padding
	size = torch.IntTensor((br[1] - ul[1], br[0] - ul[0]))

	newImg = SpecialCrop(size, 1)(newImg)
	newImg = Pad(newDim)(newImg)
	# Resize to output

	v_Img = torch.unsqueeze(newImg, 0)
	# newImg = F.upsample_bilinear(v_Img, size=(int(resH), int(resW))).data[0]
	newImg = F.upsample(v_Img, size=(int(resH), int(resW)),
						mode='bilinear', align_corners=True).data[0]
	return newImg



def vis_frame_fast(frame, im_res, format='coco'):
	'''
	frame: frame image
	im_res: im_res of predictions
	format: coco or mpii

	return rendered image
	'''
	if format == 'coco':
		l_pair = [
			(0, 1), (0, 2), (1, 3), (2, 4),  # Head
			(5, 6), (5, 7), (7, 9), (6, 8), (8, 10),
			(17, 11), (17, 12),  # Body
			(11, 13), (12, 14), (13, 15), (14, 16)
		]
		p_color = [(0, 255, 255), (0, 191, 255),(0, 255, 102),(0, 77, 255), (0, 255, 0), #Nose, LEye, REye, LEar, REar
					(77,255,255), (77, 255, 204), (77,204,255), (191, 255, 77), (77,191,255), (191, 255, 77), #LShoulder, RShoulder, LElbow, RElbow, LWrist, RWrist
					(204,77,255), (77,255,204), (191,77,255), (77,255,191), (127,77,255), (77,255,127), (0, 255, 255)] #LHip, RHip, LKnee, Rknee, LAnkle, RAnkle, Neck
		line_color = [(0, 215, 255), (0, 255, 204), (0, 134, 255), (0, 255, 50),
					(77,255,222), (77,196,255), (77,135,255), (191,255,77), (77,255,77),
					(77,222,255), (255,156,127),
					(0,127,255), (255,127,77), (0,77,255), (255,77,36)]
	elif format == 'mpii':
		l_pair = [
			(8, 9), (11, 12), (11, 10), (2, 1), (1, 0),
			(13, 14), (14, 15), (3, 4), (4, 5),
			(8, 7), (7, 6), (6, 2), (6, 3), (8, 12), (8, 13)
		]
		p_color = [PURPLE, BLUE, BLUE, RED, RED, BLUE, BLUE, RED, RED, PURPLE, PURPLE, PURPLE, RED, RED,BLUE,BLUE]
	else:
		NotImplementedError

	#im_name = im_res['imgname'].split('/')[-1]
	img = frame

	human = im_res

	part_line = {}
	kp_preds = human['keypoints']
	kp_scores = human['kp_score']
	#print(kp_scores.shape[0])
	kp_preds = torch.cat((kp_preds, torch.unsqueeze((kp_preds[5,:]+kp_preds[6,:])/2,0)))
	print(kp_scores)
	kp_scores = torch.cat((kp_scores, torch.unsqueeze((kp_scores[5,:]+kp_scores[6,:])/2,0)))
	print(kp_scores)
	#print(kp_scores)
	# Draw keypoints
	print(kp_scores.shape[0])
	for n in range(kp_scores.shape[0]):
		#print(kp_scores[n])
		if kp_scores[n] <= 0.05:
			continue
		cor_x, cor_y = int(kp_preds[n, 0]), int(kp_preds[n, 1])
		part_line[n] = (cor_x, cor_y)
		cv2.circle(img, (cor_x, cor_y), 4, p_color[n], -1)
	# Draw limbs
	for i, (start_p, end_p) in enumerate(l_pair):
		if start_p in part_line and end_p in part_line:
			start_xy = part_line[start_p]
			end_xy = part_line[end_p]

			cv2.line(img, start_xy, end_xy, line_color[i], 2*(kp_scores[start_p] + kp_scores[end_p]) + 1)
			# print(start_p)
			# print(end_p)
	return img


def vis_frame_fast_list_ver_zp(frame, im_res, format='coco'):
	'''
	frame: frame image
	im_res: im_res of predictions
	format: coco or mpii

	return rendered image
	'''

	if format == 'coco':
		l_pair = [
			(0, 1), (0, 2), (1, 3), (2, 4),  # Head
			(5, 6), (5, 7), (7, 9), (6, 8), (8, 10),
			(17, 11), (17, 12),  # Body
			(11, 13), (12, 14), (13, 15), (14, 16)
		]
		p_color = [(0, 255, 255), (0, 191, 255),(0, 255, 102),(0, 77, 255), (0, 255, 0), #Nose, LEye, REye, LEar, REar
					(77,255,255), (77, 255, 204), (77,204,255), (191, 255, 77), (77,191,255), (191, 255, 77), #LShoulder, RShoulder, LElbow, RElbow, LWrist, RWrist
					(204,77,255), (77,255,204), (191,77,255), (77,255,191), (127,77,255), (77,255,127), (0, 255, 255)] #LHip, RHip, LKnee, Rknee, LAnkle, RAnkle, Neck

		line_color = [(0, 215, 255), (0, 255, 204), (0, 134, 255), (0, 255, 50),
					(77,255,222), (77,196,255), (77,135,255), (191,255,77), (77,255,77),
					(77,222,255), (255,156,127),
					(0,127,255), (255,127,77), (0,77,255), (255,77,36)]
	elif format == 'mpii':
		l_pair = [
			(8, 9), (11, 12), (11, 10), (2, 1), (1, 0),
			(13, 14), (14, 15), (3, 4), (4, 5),
			(8, 7), (7, 6), (6, 2), (6, 3), (8, 12), (8, 13)
		]
		p_color = [PURPLE, BLUE, BLUE, RED, RED, BLUE, BLUE, RED, RED, PURPLE, PURPLE, PURPLE, RED, RED,BLUE,BLUE]
	else:
		NotImplementedError

	#im_name = im_res['imgname'].split('/')[-1]
	img = frame

	human = im_res['data']

	if 'keypoints' in human:

		kp_preds_list = copy.deepcopy(human['keypoints'])
		kp_scores_list = copy.deepcopy(human['kp_score'])
		#print('len(kp_scores_list)',len(kp_scores_list))
		#print('kp_scores_list',kp_scores_list)
		#print('kp_preds_list',kp_preds_list)
		for person_index in range(len(kp_scores_list)):
			part_line = {}
			kp_preds = kp_preds_list[person_index]
			kp_scores = kp_scores_list[person_index]
			#print ('kp_scores0: ',len(kp_scores))
			#print ('kp_preds0: ',len(kp_preds))

			kp_scores.append([(kp_scores[5][0]+kp_scores[6][0])/2])
			kp_preds.append([(kp_preds[5][0]+kp_preds[6][0])/2,(kp_preds[5][1]+kp_preds[6][1])/2])

			#print ('kp_scores1: ',len(kp_scores))
			#print ('kp_preds1: ',len(kp_preds))
			for n in range(len(kp_scores)):

				if kp_scores[n][0] <= 0.05:

					continue
				cor_x, cor_y = int(kp_preds[n][0]), int(kp_preds[n][1])
				part_line[n] = (cor_x, cor_y)
				#print('line: ',cor_x,cor_y,n)
				cv2.circle(img, (cor_x, cor_y), 4, p_color[n], -1)
				
			# Draw limbs
			for i, (start_p, end_p) in enumerate(l_pair):
				if start_p in part_line and end_p in part_line:
					start_xy = part_line[start_p]
					end_xy = part_line[end_p]
					#print('line: ',end_xy,start_xy)
					cv2.line(img, start_xy, end_xy, line_color[i], int(2*(kp_scores[start_p][0] + kp_scores[end_p][0])) + 1)



	return img


def vis_frame_fast_list_ver(frame, im_res, format='coco'):
	'''
	frame: frame image
	im_res: im_res of predictions
	format: coco or mpii

	return rendered image
	'''
	if format == 'coco':
		l_pair = [
			(0, 1), (0, 2), (1, 3), (2, 4),  # Head
			(5, 6), (5, 7), (7, 9), (6, 8), (8, 10),
			(17, 11), (17, 12),  # Body
			(11, 13), (12, 14), (13, 15), (14, 16)
		]
		p_color = [(0, 255, 255), (0, 191, 255),(0, 255, 102),(0, 77, 255), (0, 255, 0), #Nose, LEye, REye, LEar, REar
					(77,255,255), (77, 255, 204), (77,204,255), (191, 255, 77), (77,191,255), (191, 255, 77), #LShoulder, RShoulder, LElbow, RElbow, LWrist, RWrist
					(204,77,255), (77,255,204), (191,77,255), (77,255,191), (127,77,255), (77,255,127), (0, 255, 255)] #LHip, RHip, LKnee, Rknee, LAnkle, RAnkle, Neck
		line_color = [(0, 215, 255), (0, 255, 204), (0, 134, 255), (0, 255, 50),
					(77,255,222), (77,196,255), (77,135,255), (191,255,77), (77,255,77),
					(77,222,255), (255,156,127),
					(0,127,255), (255,127,77), (0,77,255), (255,77,36)]
	elif format == 'mpii':
		l_pair = [
			(8, 9), (11, 12), (11, 10), (2, 1), (1, 0),
			(13, 14), (14, 15), (3, 4), (4, 5),
			(8, 7), (7, 6), (6, 2), (6, 3), (8, 12), (8, 13)
		]
		p_color = [PURPLE, BLUE, BLUE, RED, RED, BLUE, BLUE, RED, RED, PURPLE, PURPLE, PURPLE, RED, RED,BLUE,BLUE]
	else:
		NotImplementedError

	#im_name = im_res['imgname'].split('/')[-1]
	img = frame

	human = im_res['data']

	part_line = {}
	kp_preds = human['keypoints']
	kp_scores = human['kp_score']
	kp_scores.append([(kp_scores[5][0]+kp_scores[6][0])/2])
	kp_preds.append([(kp_preds[5][0]+kp_preds[6][0])/2,(kp_preds[5][1]+kp_preds[6][1])/2])

	for n in range(len(kp_scores)):

		if kp_scores[n][0] <= 0.05:

			continue
		cor_x, cor_y = int(kp_preds[n][0]), int(kp_preds[n][1])
		part_line[n] = (cor_x, cor_y)
		cv2.circle(img, (cor_x, cor_y), 4, p_color[n], -1)
	# Draw limbs
	for i, (start_p, end_p) in enumerate(l_pair):
		if start_p in part_line and end_p in part_line:
			start_xy = part_line[start_p]
			end_xy = part_line[end_p]
			cv2.line(img, start_xy, end_xy, line_color[i], int(2*(kp_scores[start_p][0] + kp_scores[end_p][0])) + 1)



	return img


from SPPE.src.models.FastPose import createModel

class InferenNet(nn.Module):
    def __init__(self, kernel_size, dataset,weights_model):
        super(InferenNet, self).__init__()

        model = createModel().cuda()
        print('Loading pose model from {}'.format(weights_model))
        sys.stdout.flush()
        model.load_state_dict(torch.load(weights_model))
        model.eval()
        self.pyranet = model

        self.dataset = dataset

    def forward(self, x):
        out = self.pyranet(x)
        out = out.narrow(1, 0, 17)

        flip_out = self.pyranet(flip_v(x))
        flip_out = flip_out.narrow(1, 0, 17)

        flip_out = flip_v(shuffleLR(
            flip_out, self.dataset))

        out = (flip_out + out) / 2

        return out


class InferenNet_fast(nn.Module):
    def __init__(self, kernel_size, dataset,weights_model):
        super(InferenNet_fast, self).__init__()

        model = createModel().cuda()
		# weights_model = './models/sppe/duc_se.pth'
        print('Loading pose model from {}'.format(weights_model))
        model.load_state_dict(torch.load(weights_model))
        model.eval()
        self.pyranet = model

        self.dataset = dataset

    def forward(self, x):
        out = self.pyranet(x)
        out = out.narrow(1, 0, 17)

        return out



class pose_module:

	def __init__(self,init_dict):
		
		weights_model = init_dict['weights']
		cfg = init_dict['cfg']
		use_cuda = 	init_dict['use_cuda']
		# import sys
		# print(sys.argv[0])
		self.inputResH = 320
		self.inputResW = 256
		self.outputResH = 80
		self.outputResW = 64

		# Load pose model
		pose_dataset = Mscoco()
		fast_inference = True
		if fast_inference:
			pose_model = InferenNet_fast(4 * 1 + 1, pose_dataset,weights_model)
		else:
			pose_model = InferenNet(4 * 1 + 1, pose_dataset,weights_model)
		
		if use_cuda == 1:
			pose_model.cuda()

		pose_model.eval()

		self.pose_model = pose_model



	def analyze_batch(self,img_list):

		t1 = time.time()
		batchSize = len(img_list)
		pt1 = torch.zeros(batchSize, 2)
		pt2 = torch.zeros(batchSize, 2)
		boxes = torch.zeros(batchSize, 4)
		scores = torch.zeros(batchSize, 1)
		inps = torch.zeros(batchSize, 3, self.inputResH, self.inputResW)  # 320,256

		with torch.no_grad():

			for i in range(len(img_list)):

				orig_img = img_list[i]

				(ht, wd, ch) = orig_img.shape
				pt1[i] = torch.Tensor([0, 0])
				pt2[i] = torch.Tensor([wd, ht])
				boxes[i] = torch.Tensor([0, 0, wd, ht])
				scores[i] = torch.Tensor([1.0])
				inp = im_to_torch(cv2.cvtColor(orig_img, cv2.COLOR_BGR2RGB))
				inps[i] = cropBox(inp, pt1[i], pt2[i], self.inputResH, self.inputResW)

				datalen = inps.size(0)

				leftover = 0
				if (datalen) % batchSize:
					leftover = 1
				num_batches = datalen // batchSize + leftover
				hm = []  # heatmap
				for j in range(num_batches):
					inps_j = inps[j * batchSize:min((j + 1) * batchSize, datalen)].cuda()
					hm_j = self.pose_model(inps_j)
					hm.append(hm_j)
				hm = torch.cat(hm)
				hm = hm.cpu()


			preds_hm, preds_img, preds_scores = getPrediction(
				hm, pt1, pt2, self.inputResH, self.inputResW, self.outputResH, self.outputResW)

			result = []
			for i in range(len(img_list)):
				res = {}
				res['keypoints'] = preds_img[i, :]
				res['kp_score'] = preds_scores[i, :]
				res['proposal_score'] = torch.Tensor([2.5199])
				result.append(res)

			#print('--pose spent {} batch {} av {}'.format(time.time() * 1000 - t1 * 1000,batchSize,(time.time() * 1000 - t1 * 1000)/batchSize))


			return result


	def left_right_judge_front(self,x_left,x_right):
		if x_left <= x_right:
			return 0
		else:
			return 1

	def analye_human_joint(self,score,keypoints):

		joint_score = []
		for i in range(len(score)):
			joint_score.append(score[i][0])
			# if score[i][0] >= 0.05:
			# 	joint_score.append(1)
			# else:
			# 	joint_score.append(0)

		joint_dict = {"Nose":0,"LEye":1,"REye":2,"LEar":3,"REar":4,
					  "LShoulder":5,"RShoulder":6,"LElbow":7,"RElbow":8,"LWrist":9,"RWrist":10,
					  "LHip":11,"RHip":12,"LKnee":13,"Rknee":14,"LAnkle":15,"RAnkle":16}


		head_score = 0.0
		upper_body_score = 0.0
		lower_body_score = 0.0
		human_score = 0.0
		front_score = 0.0

		head_score = joint_score[joint_dict['Nose']] + joint_score[joint_dict['LEye']] + joint_score[joint_dict['REye']] + joint_score[joint_dict['LEar']] + joint_score[joint_dict['REar']]

		head_score = head_score/5.0

		upper_body_score = joint_score[joint_dict['LShoulder']] + joint_score[joint_dict['RShoulder']] + joint_score[joint_dict['LElbow']] + joint_score[joint_dict['RElbow']] + joint_score[joint_dict['LWrist']] + joint_score[joint_dict['RWrist']]

		lower_body_score = joint_score[joint_dict['LHip']] + joint_score[joint_dict['RHip']] + joint_score[joint_dict['LKnee']] + joint_score[joint_dict['Rknee']] + joint_score[joint_dict['LAnkle']] + joint_score[joint_dict['RAnkle']]

		if head_score > 0.05:
			human_score = upper_body_score + lower_body_score
			human_score = human_score/12.0
		else:
			human_score = 0.0

		upper_body_score = upper_body_score/6.0
		lower_body_score = lower_body_score/6.0

		# print(joint_score[keypoints['LShoulder']][0])
		front_score = self.left_right_judge_front(keypoints[joint_dict['LShoulder']][0],keypoints[joint_dict['RShoulder']][0])+ self.left_right_judge_front(keypoints[joint_dict['LElbow']][0],keypoints[joint_dict['RElbow']][0])+ self.left_right_judge_front(keypoints[joint_dict['LWrist']][0],keypoints[joint_dict['RWrist']][0]) + 	self.left_right_judge_front(keypoints[joint_dict['LHip']][0],keypoints[joint_dict['RHip']][0]) +	self.left_right_judge_front(keypoints[joint_dict['LKnee']][0],keypoints[joint_dict['Rknee']][0])+ 	self.left_right_judge_front(keypoints[joint_dict['LAnkle']][0],keypoints[joint_dict['RAnkle']][0])

		front_score = front_score/6.0
		#front_score = joint_score[joint_dict['Nose']]




		return head_score,upper_body_score,lower_body_score,human_score,front_score



	def up_down_judge(self,y_wrist,y_other):
		if y_wrist <= y_other:
			return 1 #down
		else:
			return 0 #up

	def angle_btw_trunk_hip(self,shoulder_cp,hip_cp,knee_p):
		x1 = shoulder_cp[0]
		y1 = shoulder_cp[1]
		x2 = hip_cp[0]
		y2 = hip_cp[1]
		x3 = knee_p[0]
		y3 = knee_p[1]
		vector1 = (x1-x2,y1-y2)
		vector2 = (y3-x2,y3-y2)
		length_v1 = math.sqrt(pow((x1 - x2), 2) + pow((y1 - y2), 2))
		length_v2 = math.sqrt(pow((x3 - x2), 2) + pow((y3 - y2), 2))
		angle_btw = np.dot(vector1,vector2)/(float(length_v1*length_v2))
		if angle_btw > 1:
			angle_btw = 1
		elif angle_btw < -1:
			angle_btw = -1
		angle_btw = np.arccos(angle_btw)*180/np.pi
		return angle_btw


	def analye_human_joint_action(self,score,keypoints):

		joint_score = []
		for i in range(len(score)):
			joint_score.append(score[i][0])
			# if score[i][0] >= 0.05:
			# 	joint_score.append(1)
			# else:
			# 	joint_score.append(0)

		joint_dict = {"Nose":0,"LEye":1,"REye":2,"LEar":3,"REar":4,
					  "LShoulder":5,"RShoulder":6,"LElbow":7,"RElbow":8,"LWrist":9,"RWrist":10,
					  "LHip":11,"RHip":12,"LKnee":13,"Rknee":14,"LAnkle":15,"RAnkle":16}


		handsup_score = 0.0
		standing_score = 0.0
		sitting_score = 0.0 #hip up

		handsup_score = self.up_down_judge(keypoints[joint_dict['LWrist']][1],keypoints[joint_dict['LShoulder']][1])+self.up_down_judge(keypoints[joint_dict['LWrist']][1],keypoints[joint_dict['RShoulder']][1])+self.up_down_judge(keypoints[joint_dict['RWrist']][1],keypoints[joint_dict['LShoulder']][1])+self.up_down_judge(keypoints[joint_dict['RWrist']][1],keypoints[joint_dict['RShoulder']][1])
		#print('Lwrist:',keypoints[joint_dict['LWrist']][1])
		#print('LShoulder:',keypoints[joint_dict['LShoulder']][1])
		#print('RWrist:',keypoints[joint_dict['RWrist']][1])
		#print('RShoulder:',keypoints[joint_dict['RShoulder']][1])
		handsup_score = handsup_score/4.0 #>=0.25,single-hands-up;>0.5,two-hands-up

		shoulder_cp = [(keypoints[joint_dict['LShoulder']][0] + keypoints[joint_dict['RShoulder']][0] )/2.0,(keypoints[joint_dict['LShoulder']][1] + keypoints[joint_dict['RShoulder']][1] )/2.0]
		hip_cp = [(keypoints[joint_dict['LHip']][0] + keypoints[joint_dict['RHip']][0] )/2.0,(keypoints[joint_dict['LHip']][1] + keypoints[joint_dict['RHip']][1] )/2.0]
		#print('points: ',shoulder_cp,hip_cp,keypoints[joint_dict['LKnee']])
		angleLknee = self.angle_btw_trunk_hip(shoulder_cp,hip_cp,keypoints[joint_dict['LKnee']])
		angleRknee = self.angle_btw_trunk_hip(shoulder_cp,hip_cp,keypoints[joint_dict['Rknee']])

		#print ('angleL:',angleLknee)
		#print ('angleR:',angleRknee)
		if angleRknee>100 and angleLknee>100:
			standing_score = 1
		elif 0<angleRknee<100 or 0<angleLknee<100:
			sitting_score = 1
		return handsup_score,standing_score,sitting_score

	def process_frame_batch(self, dic_list):
	# {0,  "Nose"},
    # {1,  "LEye"},
    # {2,  "REye"},
    # {3,  "LEar"},
    # {4,  "REar"},
    # {5,  "LShoulder"},
    # {6,  "RShoulder"},
    # {7,  "LElbow"},
    # {8,  "RElbow"},
    # {9,  "LWrist"},
    # {10, "RWrist"},
    # {11, "LHip"},
    # {12, "RHip"},
    # {13, "LKnee"},
    # {14, "Rknee"},
    # {15, "LAnkle"},
    # {16, "RAnkle"},


		if len(dic_list) >= 1:
			img_list = []
			for dic in dic_list:
				img_list.append(dic['img'])

			result = self.analyze_batch(img_list)

			for i in range(len(dic_list)):

				if 'data' not in dic_list[i]:
					dic_list[i]['data'] = {}

				res_dic = result[i]

				kp_score = res_dic['kp_score'].tolist()
				keypoints = res_dic['keypoints'].tolist()

				dic_list[i]['data']['kp_score'] = kp_score
				dic_list[i]['data']['keypoints'] = keypoints

				head_score, upper_body_score, lower_body_score, human_score,front_score = self.analye_human_joint(kp_score,keypoints)

				dic_list[i]['data']['head_score'] = head_score
				dic_list[i]['data']['upper_body_score'] = upper_body_score
				dic_list[i]['data']['lower_body_score'] = lower_body_score
				dic_list[i]['data']['human_score'] = human_score
				dic_list[i]['data']['front_score'] = front_score

				handsup_score,standing_score,sitting_score = self.analye_human_joint_action(kp_score,keypoints)
				if human_score < 0.5:
					handsup_score = -1
					standing_score = -1
					sitting_score = -1
				dic_list[i]['data']['handsup_score'] = handsup_score #>=0.5
				dic_list[i]['data']['standing_score'] = standing_score #1
				dic_list[i]['data']['sitting_score'] = sitting_score#1
				#print('a: ',handsup_score,standing_score,sitting_score)

		return dic_list

	def process_frame(self, dic):


		dic_list = self.process_frame_batch([dic])

		return dic_list[0]


	@staticmethod
	def drawing(frame,result_dict):
		vis_frame_fast_list_ver_zp(frame, result_dict)


if __name__ == '__main__':


	img_list = []

	dic_list = []
	for i in range(3):
		i+=1
		dic = {}
		path = './samples/{}.jpg'.format(i)
		orig_img = cv2.imread(path)
		dic['img']=orig_img
		dic_list.append(dic)

	init_dict = {'weights':'models/sppe/duc_se.pth','cfg':None,'use_cuda':1}
	pose_unit = pose_module(init_dict)
	
	dic_list = pose_unit.process_frame_batch(dic_list)


	t1 = time.time()
	for i in range(len(dic_list)):
		dic = dic_list[i]
		orig_img = dic['img']

		img = vis_frame_fast_list_ver(orig_img,dic)
		cv2.imwrite('result/result{}.jpg'.format(i), img)

		pose_unit.process_frame(dic)

	print('--pose spent {} '.format(time.time() * 1000 - t1 * 1000))